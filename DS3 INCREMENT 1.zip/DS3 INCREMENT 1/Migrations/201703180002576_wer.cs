namespace DS3_INCREMENT_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class wer : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
