﻿using DS3_INCREMENT_1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DS3_INCREMENT_1.Controllers
{
    public class HomeController : Controller
    {
        

        ApplicationDbContext db = new ApplicationDbContext();

       

        public ActionResult Easigas()
        {
            
            return View();
        }

        public ActionResult Total()
        {
            return View();
        }

        public ActionResult Afrox()
        {
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult stockOverView()
        {
            return View();
        }

        // For counting every single product
        public PartialViewResult countAll(){

            int sum = 0;

            foreach (Product p in db.Products.ToList())
            {
                sum += p.Quantity;
            }
            ViewBag.AllProducts = sum;
            return PartialView();
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult addProduct()
        {
            return View();
        }

        [HttpPost]
        public ActionResult addProduct(string BrandName, string Size, decimal sellPrice, decimal costPrice, int Qty)
        {
            Product p = new Product();
            p.Brand_Name = BrandName;
            p.Size = Size;
            p.Selling_Price = sellPrice;
            p.Cost_Price = costPrice;
            p.Quantity = Qty;

            try
            {
                db.Products.Add(p);
                db.SaveChanges();
                ViewBag.Msg = "Saved";
            }
            catch (Exception e)
            {
                ViewBag.Msg = "Not Saved, " + e.Message;
            }

            return RedirectToAction("Index");

            
        }
    }
}