﻿
$(function () {

    $(".incomeWell").mouseenter(function () {
        $(this).addClass('onWell');
        $(".incomeInfoDetailedInfo").css("visibility", "visible");
        $(".incomeInfo").css("visibility", "hidden");
    });
    $(".incomeWell").mouseleave(function () {
        $(this).removeClass('onWell');
        $(".incomeInfoDetailedInfo").css("visibility", "hidden");
        $(".incomeInfo").css("visibility", "visible");
    });

    $(".ordersWell").mouseenter(function () {
        $(this).addClass('onWell');
        $(".ordersInfoDetailedInfo").css("visibility", "visible");
        $(".ordersInfo").css("visibility", "hidden");
    });
    $(".ordersWell").mouseleave(function () {
        $(this).removeClass('onWell');
        $(".ordersInfoDetailedInfo").css("visibility", "hidden");
        $(".ordersInfo").css("visibility", "visible");
    });

    $(".stockWell").mouseenter(function () {
        $(this).addClass('onWell');
        $(".stockworthInfoDetailedInfo").css("visibility", "visible");
        $(".stockworthInfo").css("visibility", "hidden");
    });
    $(".stockWell").mouseleave(function () {
        $(this).removeClass('onWell');
        $(".stockworthInfoDetailedInfo").css("visibility", "hidden");
        $(".stockworthInfo").css("visibility", "visible");
    });

    //Validation

    $("#ID_Number").blur(function () {

        if ($(this).val().length < 13 || $(this).val().length > 13) {
            $(this).css("border-color","red");
        }


    });


    $("#ID_Number").keydown(function () {

        if ($(this).val().length+1 == 13 ) {
            $(this).addClass('idnum');
            $(this).css("border-color", "green");
            
        }
        else {
            $(this).removeClass('idnum');
            $(this).css("border-color", "red");
        }


    });
});