﻿
var app = angular.module("gasApp", ['ngRoute']);

app.controller('gasCtrl', function ($scope) {

    $scope.brands = ["Total","Afrox","Easigas"];
});


app.config(function ($routeProvider) {
    $routeProvider.when('/Home', {})
    .when('/ViewProducts', {
        templateUrl:'/Product/Index'
    })
    .when('/AddProducts', {
        templateUrl: '/Product/Create'
    })
    .when('/ViewEmployees', {})
    .otherwise({
        templateUrl: '/Home/stockOverView'
    });
});