﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DS3_INCREMENT_1.Models
{
    public class Product
    {   [Key]
        public int ID { get; set; }
        public string Brand_Name { get; set; }
        public string Size { get; set; }
        public decimal Selling_Price { get; set; }
        public decimal Cost_Price { get; set; }
        public int Quantity { get; set; }
    }
}